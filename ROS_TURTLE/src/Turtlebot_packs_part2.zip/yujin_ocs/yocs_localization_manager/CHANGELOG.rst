^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package yocs_localization_manager
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.6.3 (2014-12-05)
------------------

0.6.2 (2014-11-30)
------------------
* support simulation
* Merge branch 'indigo-devel' of https://github.com/yujinrobot/yujin_ocs into indigo-devel
* resetting initialise value fale when it failed to localize
  g
* typo fixes
* patch localization manager and basic move controller
* basic move controller ready
* make odom topic tobe configurable
* updates
* update navigation configurations
* removing leading slash for frame ids
* updates
* updates
* update launch
* add launch file
* Update README.md
* add ims
* updates
* forgot to start action
* localization manager now uses action
* updates
* sendtransform ..
* add queue_size
* localization manager fix
* yocs localization manager compile fix
* add localization_manager ported from init_pose_manager
* Contributors: Jihoon Lee, dwlee

* support simulation
* Merge branch 'indigo-devel' of https://github.com/yujinrobot/yujin_ocs into indigo-devel
* resetting initialise value fale when it failed to localize
  g
* typo fixes
* patch localization manager and basic move controller
* basic move controller ready
* make odom topic tobe configurable
* updates
* update navigation configurations
* removing leading slash for frame ids
* updates
* updates
* update launch
* add launch file
* Update README.md
* add ims
* updates
* forgot to start action
* localization manager now uses action
* updates
* sendtransform ..
* add queue_size
* localization manager fix
* yocs localization manager compile fix
* add localization_manager ported from init_pose_manager
* Contributors: Jihoon Lee, dwlee

0.6.1 (2014-07-08 11:21)
------------------------

0.6.0 (2014-07-08 11:07)
------------------------

0.5.3 (2014-03-24)
------------------

0.5.2 (2013-11-06)
------------------

0.5.1 (2013-10-14)
------------------

0.5.0 (2013-10-11 16:44)
------------------------

0.4.2 (2013-10-11 16:17)
------------------------

0.4.1 (2013-10-08)
------------------

0.4.0 (2013-09-23 11:17)
------------------------

0.3.0 (2013-07-02)
------------------

0.2.3 (2013-09-23 11:23)
------------------------

0.2.2 (2013-02-10)
------------------

0.2.1 (2013-02-08)
------------------

0.2.0 (2013-02-07)
------------------

0.1.3 (2013-01-08)
------------------

0.1.2 (2013-01-02)
------------------

0.1.1 (2012-12-21)
------------------

0.1.0 (2012-12-05)
------------------
